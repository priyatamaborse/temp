package assignment.com.yash.training;

import java.util.Scanner;

public class MyScanner {

	  private final Scanner scanner = new Scanner(System.in);
      
      public int nextInt() {

          return scanner.nextInt();
      }

}
