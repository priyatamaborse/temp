package assignment.com.yash.training;

public class MenuLauncher {

	public static void main(String[] args) {
	
		TeaCoffeeVendingMachineSimulator teaCoffeeVendingMachineSimulator = new TeaCoffeeVendingMachineSimulator();
		teaCoffeeVendingMachineSimulator.menuList();
	}

}
